package com.example.datacheck.constant;

/**
 * created by yuanjunjie on 2019/1/3 5:22 PM
 */
public interface CommonConstants {

    /**
     * 成功标记
     */
    Integer SUCCESS=0;
    /**
     * 失败标记
     */
    Integer FAIL=1;

    /**
     * 任务进行中
     */
    Integer STARTING=2;
}
